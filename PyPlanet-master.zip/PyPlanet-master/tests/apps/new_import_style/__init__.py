from pyplanet.apps.config import AppConfig


class NewImportStyle(AppConfig):
	pass
