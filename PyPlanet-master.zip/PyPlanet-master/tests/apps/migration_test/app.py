
from . import MigrationTest as RealMigrationTest

MigrationTest = RealMigrationTest
