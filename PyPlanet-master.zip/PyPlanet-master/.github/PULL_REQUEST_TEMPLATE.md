<!-- Thank you for your contribution! Please replace {Please write here} with your description -->

## Motivation or cause

{Please write here}

## Change description

{Please write here}

## Checklist of pull request

Make sure that your pull request follow the following 'rules':

- I have read the **CONTRIBUTING** document.
- My code follows the code style of this project.
- All new and existing tests passed, except in few situations.
- My change requires a change to the documentation.

Please leave a comment here if your pull need any updates for the docs or tests.

### Additional Comments (optional)

{Please write here}
