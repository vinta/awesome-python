
from . import LocalRecords as RealLocalRecords

LocalRecords = RealLocalRecords
