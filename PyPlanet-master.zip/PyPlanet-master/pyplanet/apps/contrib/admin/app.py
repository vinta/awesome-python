
from . import Admin as RealAdmin

Admin = RealAdmin
