"""
.. deprecated:: 0.4.0
	Use ``pyplanet.apps.contrib.info`` instead!
"""
from . import MapInfo as RealMapInfo
MapInfo = RealMapInfo
