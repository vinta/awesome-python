
from . import Statistics as RealStatistics

StatisticsConfig = RealStatistics
