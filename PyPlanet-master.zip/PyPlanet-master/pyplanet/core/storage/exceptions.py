
class StorageException(Exception):
	"""Base storage exception."""
