"""
PyPlanet python module (when running python -m pyplanet). Will start the CLI.
"""
from pyplanet.core import management

if __name__ == '__main__':
	management.execute_from_command_line()
