"""
PyPlanet, a robust and simple Maniaplanet Server Controller for Python 3.5+.
Please see LICENSE file in root of project.
"""
__version__ = '0.6.3'
__author__ = 'Tom Valk'
