

class ChatException(Exception):
	pass
