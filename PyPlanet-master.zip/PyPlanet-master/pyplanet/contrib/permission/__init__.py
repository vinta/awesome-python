"""
The permission contrib will provide permission abilities to players and admin levels.
"""
from .manager import PermissionManager

__all__ = [
	'PermissionManager'
]
