
pyplanet.core.events
====================

.. automodule:: pyplanet.core.events.manager
  :members:

.. autoclass:: pyplanet.core.events.manager._SignalManager
  :members:

pyplanet.core.events.callback
-----------------------------

.. automodule:: pyplanet.core.events.callback
  :members:

pyplanet.core.events.dispatcher
-------------------------------

.. automodule:: pyplanet.core.events.dispatcher
  :members:
