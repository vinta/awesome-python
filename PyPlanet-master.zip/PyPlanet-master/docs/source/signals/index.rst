
Signals (callbacks)
===================


.. contents::
.. toctree::
  :glob:

  *
