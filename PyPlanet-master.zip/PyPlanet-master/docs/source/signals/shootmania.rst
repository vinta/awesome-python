
Shootmania
----------

Base
~~~~

.. automodule:: pyplanet.apps.core.shootmania.callbacks.base
  :members:

Elite
~~~~~

.. automodule:: pyplanet.apps.core.shootmania.callbacks.elite
  :members:

Joust
~~~~~

.. automodule:: pyplanet.apps.core.shootmania.callbacks.joust
  :members:

Royal
~~~~~

.. automodule:: pyplanet.apps.core.shootmania.callbacks.royal
  :members:
