
Apps Architecture
-----------------

..  image:: /_static/apps/architecture.png
