
Core Architecture
-----------------

The architecture of the core and plugins is described in the sections bellow.

**Inspiration**.

While developing the Core we did look at how Django is managing their so called Apps. Because these apps are self contained
applications on it's own, we also call it Apps.

.. image:: /_static/architecture-overview.png


.. note::

  This image is only describing the most important core components, some components are not shown here.
