
==============================
Getting Started (installation)
==============================

.. toctree::
  :glob:
  :maxdepth: 1

  requirements
  installation-simple
  installation-linux
  installation-windows
