"""Psychological analyzer agents."""
