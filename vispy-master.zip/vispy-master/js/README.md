A Custom Jupyter Widget Library for the VisPy Python Library

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save vispy
```
